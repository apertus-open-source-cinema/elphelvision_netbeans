
	java -jar -Xmx256m ElphelVision-linux.jar
	     