
	     java -jar -Xmx256m ElphelVision-dist.jar --debuglevel 3
        